import javafx.animation.KeyFrame;
import javafx.application.Application;
import javafx.event.*;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.geometry.Insets;
import javafx.scene.layout.*;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.animation.Timeline;
import javafx.util.Duration;
import javafx.geometry.Point2D;
import java.awt.*;
import java.util.Random;

public class SliderApp extends Application {
    Button[][] buttons; // This will store all the Buttons
    Point2D[][] coordinates; // This will store the coordinates
    String[][] images; //This stores the names of the images in string format
    Button startButton;
    int completecounter=0; // Keeps count if each piece is in correct spot

    public int seconds = 0;
    public int minutes = 0;


    //main swap method, that swaps valid adjacent blank pieces if they are there, otherwise swap a random valid adjacent piece
    public void swap(int row, int col) {
        //if (row-1>=0 || row+1<=3 || col-1>=0 || col+1<=3) {
        int [] searchArray = new int[8];
        int cursor=0;
        if (row+1<=3){
            searchArray[cursor]=row+1;
            searchArray[cursor+1]=col;
            cursor = cursor+2;
        }
        if (col+1<=3){
            searchArray[cursor]=row;
            searchArray[cursor+1]=col+1;
            cursor = cursor+2;
        }
        if (row-1>=0){
            searchArray[cursor]=row-1;
            searchArray[cursor+1]=col;
            cursor = cursor+2;
        }
        if (col-1>=0){
            searchArray[cursor]=row;
            searchArray[cursor+1]=col-1;
            cursor = cursor+2;
        }

        for (int i = 0; i<cursor; i=i+2){
            int rLook = searchArray[i];
            int cLook = searchArray[i+1];
            //if rLook,cLook blank then swap

            if (images[rLook][cLook].equals("BLANK.png")){
                buttons[rLook][cLook].setGraphic(new ImageView(new Image(getClass().getResourceAsStream(images[row][col]))));
                buttons[row][col].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                images[rLook][cLook] = images[row][col];
                images[row][col] = "BLANK.png";
                Point2D newBLANK = new Point2D(rLook,cLook);
                coordinates[rLook][cLook] = coordinates[row][col];
                coordinates[row][col] = newBLANK;
            } else if (startButton.getText().equals("Stop")) {

            } else {
                //pick a random valid adjacent to swap with
                Random rand = new Random();
                int randAdjacent = rand.nextInt(cursor/2);
                rLook = searchArray[randAdjacent*2];
                cLook = searchArray[randAdjacent*2 + 1];

                buttons[rLook][cLook].setGraphic(new ImageView(new Image(getClass().getResourceAsStream(images[row][col]))));
                buttons[row][col].setGraphic(new ImageView(new Image(getClass().getResourceAsStream(images[rLook][cLook]))));
                String originalRLOOKCLOOK= images[rLook][cLook];
                images[rLook][cLook] = images[row][col];
                images[row][col] = originalRLOOKCLOOK;
                Point2D newBLANK = new Point2D(rLook,cLook);
                coordinates[rLook][cLook] = coordinates[row][col];
                coordinates[row][col] = newBLANK;
            }
        }
    }

    public void start(Stage primaryStage) {
        Pane gamePane = new Pane();



        // THUMBNAIL PIC--------------------------------------------------------------------------------------
        Label label1 = new Label();
        //label1.setGraphic(new ImageView(new Image((getClass().getResourceAsStream("Lego_Thumbnail.png")))));
        label1.setGraphic(new ImageView(new Image((getClass().getResourceAsStream("BLANK.png")))));
        label1.relocate(772, 10);
        gamePane.getChildren().add(label1);

        // Time Label------------------------------------------------------------------------------------------
        Label label2 = new Label("Time:");
        label2.relocate(772, 416);
        gamePane.getChildren().add(label2);

        // Time TextField----------------------------------------------------------------------------------------
        TextField timeField;
        timeField = new TextField();
        timeField.relocate(835, 405);
        timeField.setPrefSize(125,30);
        timeField.setText("0:00");
        timeField.setEditable(false);
        gamePane.getChildren().add(timeField);


        //setup the timer, such that it counts up each second------------------------------------------------------
        Timeline updateTimer = new Timeline(new KeyFrame(Duration.millis(1000),
                new EventHandler<ActionEvent>() {
                    public void handle(ActionEvent event) {
                        seconds++;
                        timeField.setText(Integer.toString(minutes) + ":" + String.format("%02d",seconds));
                        if (seconds == 59) {
                            minutes++;
                        }
                        if (seconds == 60) {
                            timeField.setText(Integer.toString(minutes) + ":" + "00");
                        }
                        if (seconds == 61) {
                            seconds = 0;
                            seconds++;
                            timeField.setText(Integer.toString(minutes) + ":" + String.format("%02d",seconds));
                        }


                    } }));
        updateTimer.setCycleCount(Timeline.INDEFINITE);


        // list of pictures-------------------------------------------------------------------------------------------
        ListView<String> picList = new ListView<String>();
        String[] pics = {"Pets", "Scenery", "Lego", "Numbers"};
        picList.setItems(FXCollections.observableArrayList(pics));
        picList.relocate(772, 207);
        picList.setPrefSize(187, 150);
        gamePane.getChildren().add(picList);

        // 2D array for image names----------------------------------------------------------------------------------
        images = new String[4][4];

        //Make a couple of 2D arrays to store game info----------------------------------------------------------------
        coordinates = new Point2D[4][4];
        buttons = new Button[4][4];

        //list event handler---------------------------------------------------------------------------------------------------
        picList.setOnMouseClicked(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {
                String answer = picList.getSelectionModel().getSelectedItem();
                label1.setGraphic(new ImageView(new Image((getClass().getResourceAsStream(answer + "_Thumbnail.png")))));

                for(int row=0; row<4; row++) {
                    for (int col = 0; col < 4; col++) {
                        if (answer.equals("Lego")){
                            images[row][col] = "Lego_" + row + col + ".png";
                        }
                        else if (answer.equals("Pets")){
                            images[row][col] = "Pets_" + row + col + ".png";
                        }

                        else if (answer.equals("Numbers")){
                            images[row][col] = "Numbers_" + row + col + ".png";
                        }

                        else if (answer.equals("Scenery")){
                            images[row][col] = "Scenery_" + row + col + ".png";
                        }

                    }
                }


            }
        });






        // 2D array of the buttons----------------------------------------------------------------------------------------------------
        for(int row=0; row<4; row++) {
            for (int col = 0; col < 4; col++) {


                //***buttons***-----------------
                buttons[row][col] = new Button();
                buttons[row][col].relocate(10 + col * 188,10+ row * 188);
                buttons[row][col].setPrefSize(187, 187);
                //buttons[row][col].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Lego_" + row + col +".png"))));
                buttons[row][col].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                buttons[row][col].setPadding(new Insets (0,0,0,0));
                gamePane.getChildren().add(buttons[row][col]);


                //***Point2D***-----------------------------
                coordinates[row][col] = new Point2D(row,col);




                // Determine which button was clicked----------------------------
                buttons[row][col].setOnAction(new EventHandler<ActionEvent>() {
                    // This is the single event handler for all of the buttons
                    public void handle(ActionEvent event) {
                        // Find the row and column of the pressed button
                        for (int row = 0; row < 4; row++) {
                            for (int col = 0; col < 4; col++) {
                                if (event.getSource() == buttons[row][col]) {

                                    swap(row,col);
                                    //check for how many in right spot-----------------------------------------------
                                    if (row == coordinates[row][col].getX() && col == coordinates[row][col].getY()) {
                                        completecounter++;
                                    }







                                }
                            }
                        }
                        completecounter = 0;
                    }
                });

            }
        }




        // button------------------------------------------------------------------------------
        startButton = new Button("Start");
        startButton.setStyle("-fx-font: 12 arial; -fx-base: DARKGREEN; -fx-text-fill: WHITE;");
        startButton.relocate(772, 366);
        startButton.setPrefSize(187,30);
        gamePane.getChildren().add(startButton);




        //button event handler--------------------------------------------------------------------------------------------------------
        startButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {


                if (startButton.getText().equals("Start")) {

                    //when start button is pressed, the 4x4 grid is populated with the selected picture
                    for(int row=0; row<4; row++) {
                        for (int col = 0; col < 4; col++) {
                            buttons[row][col].setGraphic(new ImageView(new Image(getClass().getResourceAsStream(images[row][col]))));
                        }
                    }


                    //Scramble it up well at START
                    for (int i = 0; i < 25; i ++) {
                        Random randomROW = new Random();
                        Random randomCOL = new Random();
                        int valueROW = randomROW.nextInt(4);
                        int valueCOL = randomCOL.nextInt(4);
                        swap(valueROW,valueCOL);

                    }

                    //make a random square blank and save the picture that was turned blank
                    Random randomBLANKrow = new Random();
                    Random randomBLANKcol = new Random();
                    int valueBLANKrow = randomBLANKrow.nextInt(4);
                    int valueBLANKcol = randomBLANKcol.nextInt(4);
                    buttons[valueBLANKrow][valueBLANKcol].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    String savedBLANK = images[valueBLANKrow][valueBLANKcol];
                    images[valueBLANKrow][valueBLANKcol] = "BLANK.png";

                    startButton.setText("Stop");
                    startButton.setStyle("-fx-font: 12 arial; -fx-base: DARKRED; -fx-text-fill: WHITE;");
                    label1.setDisable(true);
                    picList.setDisable(true);
                    seconds = 0;
                    minutes = 0;
                    timeField.setText("0:00");
                    updateTimer.play();


                    //check if all 15 pieces are counted
                    if (completecounter == 15) {
                        for(int row=0; row<4; row++) {
                            for (int col = 0; col < 4; col++) {
                                if (images[row][col].equals("BLANK.png")) {
                                    buttons[row][col].setGraphic(new ImageView(new Image(getClass().getResourceAsStream(savedBLANK))));
                                    updateTimer.stop();
                                }


                            }

                        }
                    }


                } else {


                    // when the stop button is pressed
                    startButton.setText("Start");
                    startButton.setStyle("-fx-font: 12 arial; -fx-base: DARKGREEN; -fx-text-fill: WHITE;");
                    label1.setDisable(false);
                    picList.setDisable(false);
                    updateTimer.stop();

                    //Reset the images such that there are doubled blank ones at the start of a new game
                    String answer = picList.getSelectionModel().getSelectedItem();

                    for(int row=0; row<4; row++) {
                        for (int col = 0; col < 4; col++) {
                            if (answer.equals("Lego")){
                                images[row][col] = "Lego_" + row + col + ".png";
                            }
                            else if (answer.equals("Pets")){
                                images[row][col] = "Pets_" + row + col + ".png";
                            }

                            else if (answer.equals("Numbers")){
                                images[row][col] = "Numbers_" + row + col + ".png";
                            }

                            else if (answer.equals("Scenery")){
                                images[row][col] = "Scenery_" + row + col + ".png";
                            }

                        }
                    }





                }


            }
        });





        primaryStage.setTitle("Slider Game");
        primaryStage.setScene(new Scene(gamePane, 970, 770));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }




}
